interface Shape
{
   public double getArea();
   public double getPerimeter();
   public int compareTo(Shape shape);
}